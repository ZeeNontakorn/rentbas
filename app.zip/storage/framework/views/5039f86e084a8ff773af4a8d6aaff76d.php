<script>
    var options =
    {
        chart: {
            type: '<?php echo $chart->type(); ?>',
            height: <?php echo $chart->height(); ?>,
            width: '<?php echo $chart->width(); ?>',
            toolbar: <?php echo $chart->toolbar(); ?>,
            zoom: <?php echo $chart->zoom(); ?>,
            fontFamily: '<?php echo $chart->fontFamily(); ?>',
            foreColor: '<?php echo $chart->foreColor(); ?>',
            sparkline: <?php echo $chart->sparkline(); ?>,
            <?php if($chart->stacked()): ?>
            stacked: <?php echo $chart->stacked(); ?>,
            <?php endif; ?>
        },
        plotOptions: {
            bar: <?php echo $chart->horizontal(); ?>,
            
            <?php if($chart->type() === 'heatmap'): ?>
            heatmap: {
                shadeIntensity: 0,
                enableShades: false,
                radius: 2,
                colorScale: {
                    ranges: [
                        { from: 0, to: 0, color: '#10b981', name: 'ว่าง' },
                        { from: 1, to: 1, color: '#f97316', name: 'มีคนใช้' },
                        { from: 2, to: 2, color: '#ef4444', name: 'ปิดซ่อม' },
                    ],
                },
            },
            <?php endif; ?>
        },
        colors: <?php echo $chart->colors(); ?>,
        series: <?php echo $chart->dataset(); ?>,
        dataLabels: <?php echo $chart->dataLabels(); ?>,
        <?php if($chart->labels()): ?>
        
            labels: <?php echo json_encode($chart->labels(), true); ?>,
        <?php endif; ?>
        title: {
            text: "<?php echo $chart->title(); ?>"
        },
        subtitle: {
            text: '<?php echo $chart->subtitle(); ?>',
            align: '<?php echo $chart->subtitlePosition(); ?>'
        },
        xaxis: <?php echo $chart->xAxis(); ?>,
        yaxis: {
            labels : {
                show: <?php echo json_encode($chart->showYAxisLabels(), true); ?>,
            }
        },
        <?php if($chart->yAxis()): ?>
            yaxis: <?php echo $chart->yAxis(); ?>,
        <?php endif; ?>
        grid: <?php echo $chart->grid(); ?>,
        markers: <?php echo $chart->markers(); ?>,
        <?php if($chart->stroke()): ?>
            stroke: <?php echo $chart->stroke(); ?>,
        <?php endif; ?>
        legend: {
            show: <?php echo $chart->showLegend(); ?>

        },
        states: <?php echo json_encode($chart->states()['states']); ?>

    }

    var chartElement = document.querySelector("#<?php echo $chart->id(); ?>");
    var chart = new ApexCharts(chartElement, options);
    chart.render().then(function () {
        if (!options.legend.show) {
            chartElement.querySelectorAll('.apexcharts-legend').forEach(function (legend) {
                legend.remove();
            });
        }
    });

</script>
<?php /**PATH C:\Users\User\Documents\GitHub\rentbas\resources\views/vendor/larapex-charts/chart/script.blade.php ENDPATH**/ ?>