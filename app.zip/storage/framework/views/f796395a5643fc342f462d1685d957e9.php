<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'button',
    'variant' => 'primary',
    'icon' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'button',
    'variant' => 'primary',
    'icon' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $baseClasses = 'inline-flex items-center gap-2 rounded-lg px-8 py-2.5 transition shadow-sm font-semibold text-sm';
    $variantClasses = match ($variant) {
        'reset' => 'px-6 border border-gray-300 text-gray-700 hover:bg-gray-50 shadow-none font-medium',
        default => 'bg-orange-500 text-white hover:bg-orange-600',
    };
?>

<button type="<?php echo e($type); ?>" <?php echo e($attributes->merge(['class' => $baseClasses . ' ' . $variantClasses])); ?>>
    <?php if($icon === 'check'): ?>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
        </svg>
    <?php endif; ?>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\User\Documents\GitHub\rentbas\resources\views/components/form-action-button.blade.php ENDPATH**/ ?>