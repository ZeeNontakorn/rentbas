<?php $__env->startSection('title', 'Dashboard'); ?>

<?php
    // ---- KPI card presentation config (matches the Ref design) ----
    $trendChip = function ($t) {
        if ($t === null) return null;
        $up = $t >= 0;
        return [
            'up' => $up,
            'text' => ($up ? '↗ +' : '↘ ') . abs($t) . '%',
        ];
    };

    // Build an SVG polyline path from a list of values, fitted to w×h.
    $sparkPath = function (array $vals, $w, $h) {
        $n = count($vals);
        if ($n < 2) return '';
        $max = max($vals); $min = min($vals);
        $range = max($max - $min, 1);
        $pts = [];
        foreach (array_values($vals) as $i => $v) {
            $x = round($i / ($n - 1) * $w, 1);
            $y = round($h - (($v - $min) / $range) * $h, 1);
            $pts[] = "$x,$y";
        }
        return 'M' . implode(' L', $pts);
    };

    $kpiCards = [
        ['key' => 'today_bookings',   'label' => "Today's Bookings",     'grad' => ['#fb923c', '#f97316'], 'icon' => 'calendar', 'spark' => true],
        ['key' => 'utilization',      'label' => 'Court Utilization Rate','grad' => ['#34d399', '#10b981'], 'icon' => 'check',    'suffix' => '%'],
        ['key' => 'booked_hours',     'label' => 'Booked Hours',          'grad' => ['#818cf8', '#6366f1'], 'icon' => 'clock',    'suffix' => 'h'],
        ['key' => 'active_customers', 'label' => 'Active Customers',      'grad' => ['#38bdf8', '#0ea5e9'], 'icon' => 'users'],
        ['key' => 'pending',          'label' => 'Pending Bookings',      'grad' => ['#fbbf24', '#f59e0b'], 'icon' => 'alert'],
        ['key' => 'cancellation_rate','label' => 'Cancellation Rate',     'grad' => ['#fb7185', '#e11d48'], 'icon' => 'x',        'suffix' => '%', 'invert' => true],
    ];

    $icons = [
        'calendar' => 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
        'check'    => 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z',
        'clock'    => 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z',
        'users'    => 'M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 10-4 0m8 0a4 4 0 10-3-7.75',
        'alert'    => 'M12 9v2m0 4h.01M5.07 19h13.86a2 2 0 001.74-3L13.74 4a2 2 0 00-3.48 0L3.33 16a2 2 0 001.74 3z',
        'x'        => 'M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z',
    ];
?>

<?php $__env->startSection('content'); ?>
<div class="bg-slate-50 text-gray-900 min-h-screen py-8">
    <div class="container mx-auto px-4 sm:px-6 max-w-7xl">

        <!-- Header -->
        <div class="mb-6 flex flex-wrap items-end justify-between gap-2">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Dashboard</h1>
                <p class="text-sm text-gray-500">ภาพรวมสุขภาพธุรกิจสนามบาส · <?php echo e(now()->translatedFormat('l d F Y')); ?></p>
            </div>
            <span class="text-xs text-gray-400 flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                อัปเดตล่าสุด <?php echo e(now()->format('H:i')); ?>

            </span>
        </div>

        <!-- ============ KPI CARDS ============ -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <?php $__currentLoopData = $kpiCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $k = $kpis[$card['key']];
                    $chip = $trendChip($k['trend'] ?? null);
                    // For cancellation, a rising number is bad — flip the chip colour.
                    $good = $chip ? ($chip['up'] xor ($card['invert'] ?? false)) : true;
                ?>
                <div class="relative overflow-hidden rounded-2xl p-5 text-white shadow-lg"
                     style="background-image: linear-gradient(135deg, <?php echo e($card['grad'][0]); ?>, <?php echo e($card['grad'][1]); ?>);">
                    <div class="flex items-start justify-between">
                        <div class="w-10 h-10 rounded-xl bg-white/25 flex items-center justify-center backdrop-blur-sm">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($icons[$card['icon']]); ?>"/>
                            </svg>
                        </div>
                        <?php if($chip): ?>
                            <span class="text-xs font-semibold px-2 py-1 rounded-full <?php echo e($good ? 'bg-white/25' : 'bg-black/20'); ?>">
                                <?php echo e($chip['text']); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="mt-4 text-sm font-medium text-white/85"><?php echo e($card['label']); ?></div>
                    <div class="text-3xl font-extrabold tracking-tight">
                        <?php echo e(number_format($k['value'], ($card['key'] === 'cancellation_rate') ? 1 : 0)); ?><?php echo e($card['suffix'] ?? ''); ?>

                    </div>

                    <?php if(($card['spark'] ?? false) && !empty($k['spark'])): ?>
                        <svg viewBox="0 0 120 32" preserveAspectRatio="none" class="w-full h-8 mt-2 opacity-90">
                            <path d="<?php echo e($sparkPath($k['spark'], 120, 30)); ?>" fill="none" stroke="white" stroke-width="2"
                                  stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
                        </svg>
                    <?php else: ?>
                        <div class="h-8 mt-2"></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- ============ BOOKING TREND + CANCELLATION ============ -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">

            <!-- Booking Trend (area) -->
            <div class="lg:col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h3 class="font-bold text-gray-800">Booking Trend</h3>
                        <p class="text-xs text-gray-400">Daily bookings — last 30 days</p>
                    </div>
                    <span class="text-xs font-semibold text-orange-600 bg-orange-50 px-2.5 py-1 rounded-full">
                        Total: <?php echo e(number_format($trendTotal)); ?>

                    </span>
                </div>
                <?php echo $trendChart->container(); ?>

            </div>

            <!-- Cancellation Analysis (donut) -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="flex items-start justify-between mb-2">
                    <div>
                        <h3 class="font-bold text-gray-800">Cancellation Analysis</h3>
                        <p class="text-xs text-gray-400">Reasons this month</p>
                    </div>
                    <?php if($cancelIsMock): ?>
                        <span class="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">ตัวอย่าง</span>
                    <?php endif; ?>
                </div>
                <?php echo $cancelChart->container(); ?>

            </div>
        </div>

        <!-- ============ MONTHLY VOLUME + PEAK HOURS ============ -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">

            <!-- Monthly Booking Volume (bars) -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="flex items-start justify-between mb-4">
                    <div>
                        <h3 class="font-bold text-gray-800">Monthly Booking Volume</h3>
                        <p class="text-xs text-gray-400">Last 12 months</p>
                    </div>
                    <span class="text-xs font-semibold <?php echo e($yoy >= 0 ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'); ?> px-2.5 py-1 rounded-full">
                        <?php echo e($yoy >= 0 ? '+' : ''); ?><?php echo e($yoy); ?>% YoY
                    </span>
                </div>
                <?php echo $monthlyChart->container(); ?>

            </div>

            <!-- Peak Booking Hours -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="mb-4">
                    <h3 class="font-bold text-gray-800">Peak Booking Hours</h3>
                    <p class="text-xs text-gray-400">Utilization by time slot, today</p>
                </div>
                <?php echo $peakChart->container(); ?>

            </div>
        </div>

        <!-- ============ COURT UTILIZATION (rings) ============ -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-6">
            <div class="mb-5">
                <h3 class="font-bold text-gray-800">Court Utilization</h3>
                <p class="text-xs text-gray-400">Usage per court, this week</p>
            </div>
            <?php if(count($courtCharts)): ?>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php $__currentLoopData = $courtCharts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex flex-col items-center">
                        <?php echo $cc['chart']->container(); ?>

                        <span class="-mt-3 text-xs text-gray-400"><?php echo e($cc['hours']); ?>h / สัปดาห์</span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
                <p class="text-sm text-gray-400 text-center py-6">ยังไม่มีข้อมูลสนาม</p>
            <?php endif; ?>
        </div>

        <!-- ============ OCCUPANCY TIMELINE ============ -->
        <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-6">
            <div class="flex flex-wrap items-start justify-between gap-2 mb-4">
                <div>
                    <h3 class="font-bold text-gray-800">Occupancy Timeline</h3>
                    <p class="text-xs text-gray-400">Live status across courts, today <?php echo e(sprintf('%02d:00', $occupancyHours[0] ?? 8)); ?>–22:00</p>
                </div>
            </div>
            <?php if(count($occupancy)): ?>
                <div class="overflow-x-auto"><?php echo $occChart->container(); ?></div>
            <?php else: ?>
                <p class="text-sm text-gray-400 text-center py-6">ยังไม่มีข้อมูลสนาม</p>
            <?php endif; ?>
        </div>

        <!-- ============ TODAY'S SCHEDULE + UPCOMING ============ -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">

            <!-- Today's Schedule -->
            <div class="lg:col-span-2 bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="mb-4">
                    <h3 class="font-bold text-gray-800">Today's Schedule</h3>
                    <p class="text-xs text-gray-400">All confirmed sessions for today</p>
                </div>
                <?php
                    $stateBadge = [
                        'completed' => ['bg-gray-100 text-gray-500', 'เสร็จแล้ว', '#9ca3af'],
                        'ongoing'   => ['bg-emerald-100 text-emerald-600', 'กำลังใช้งาน', '#10b981'],
                        'upcoming'  => ['bg-blue-100 text-blue-600', 'กำลังจะถึง', '#3b82f6'],
                    ];
                ?>
                <div class="space-y-2 max-h-80 overflow-y-auto pr-1">
                    <?php $__empty_1 = true; $__currentLoopData = $todaysSchedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $b = $stateBadge[$s['state']]; ?>
                        <div class="flex items-center justify-between p-3 rounded-xl border border-gray-100 hover:bg-slate-50 transition">
                            <div class="flex items-center gap-3">
                                <span class="w-2 h-2 rounded-full shrink-0" style="background: <?php echo e($b[2]); ?>;"></span>
                                <div>
                                    <div class="text-sm font-semibold text-gray-800"><?php echo e($s['name']); ?></div>
                                    <div class="text-xs text-gray-400"><?php echo e($s['time']); ?> · <?php echo e($s['court']); ?> · <?php echo e(rtrim(rtrim(number_format($s['hours'], 1), '0'), '.')); ?>h</div>
                                </div>
                            </div>
                            <span class="text-xs font-medium px-2.5 py-1 rounded-full <?php echo e($b[0]); ?>"><?php echo e($b[1]); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-400 text-center py-8">วันนี้ยังไม่มีการจองที่ยืนยันแล้ว</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Upcoming Bookings -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="mb-4">
                    <h3 class="font-bold text-gray-800">Upcoming Bookings</h3>
                    <p class="text-xs text-gray-400">Starting soon</p>
                </div>
                <div class="space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-3 rounded-xl border-l-4 border-orange-400 bg-orange-50/50">
                            <div>
                                <div class="text-sm font-semibold text-gray-800"><?php echo e($u['name']); ?></div>
                                <div class="text-xs text-gray-400"><?php echo e($u['court']); ?> · <?php echo e($u['time']); ?></div>
                            </div>
                            <span class="text-xs font-semibold text-orange-600 whitespace-nowrap">in <?php echo e($u['in']); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-400 text-center py-8">ไม่มีคิวที่กำลังจะถึง</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ============ TOP CUSTOMERS + RECENT ACTIVITIES ============ -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">

            <!-- Top Customers -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="mb-4">
                    <h3 class="font-bold text-gray-800">Top Customers</h3>
                    <p class="text-xs text-gray-400">By total hours booked, this month</p>
                </div>
                <?php $avatarGrad = [['#fb923c','#f97316'],['#818cf8','#6366f1'],['#34d399','#10b981'],['#f472b6','#ec4899'],['#38bdf8','#0ea5e9']]; ?>
                <div class="space-y-2">
                    <?php $__empty_1 = true; $__currentLoopData = $topCustomers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition">
                            <div class="flex items-center gap-3">
                                <div class="w-10 h-10 rounded-lg flex items-center justify-center text-white text-xs font-bold shrink-0"
                                     style="background-image: linear-gradient(135deg, <?php echo e($avatarGrad[$i % 5][0]); ?>, <?php echo e($avatarGrad[$i % 5][1]); ?>);">
                                    <?php echo e($c['initials']); ?>

                                </div>
                                <div>
                                    <div class="text-sm font-semibold text-gray-800"><?php echo e($c['name']); ?></div>
                                    <div class="text-xs text-gray-400"><?php echo e($c['count']); ?> bookings</div>
                                </div>
                            </div>
                            <span class="text-sm font-bold text-gray-700"><?php echo e($c['hours']); ?>h</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-400 text-center py-8">ยังไม่มีข้อมูลลูกค้าเดือนนี้</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recent Activities -->
            <div class="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div class="mb-4">
                    <h3 class="font-bold text-gray-800">Recent Activities</h3>
                    <p class="text-xs text-gray-400">Live activity feed</p>
                </div>
                <?php
                    $actDot = ['new' => '#3b82f6', 'cancel' => '#ef4444', 'confirm' => '#10b981', 'user' => '#8b5cf6'];
                ?>
                <div class="space-y-3">
                    <?php $__empty_1 = true; $__currentLoopData = $recentActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex items-start gap-3">
                            <span class="w-2 h-2 rounded-full mt-1.5 shrink-0" style="background: <?php echo e($actDot[$a['type']] ?? '#94a3b8'); ?>;"></span>
                            <div>
                                <div class="text-sm text-gray-700"><?php echo e($a['text']); ?></div>
                                <div class="text-xs text-gray-400"><?php echo e($a['ago']); ?></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-sm text-gray-400 text-center py-6">ยังไม่มีกิจกรรม</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ============ MEMBERSHIP + VISIT STATS (team lead request) ============ -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 class="font-bold text-gray-800">สถิติผู้สมัครสมาชิก (Users)</h3>
                <p class="text-xs text-gray-400 mb-2">เปรียบเทียบสัปดาห์นี้ กับ ยอดรวมเดือนนี้</p>
                <?php echo $memberChart->container(); ?>

            </div>
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 class="font-bold text-gray-800">สถิติผู้เข้าชมเว็บไซต์ (Visits)</h3>
                <p class="text-xs text-gray-400 mb-2">เปรียบเทียบสัปดาห์นี้ กับ ยอดรวมเดือนนี้</p>
                <?php echo $visitChart->container(); ?>

            </div>
        </div>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(\ArielMejiaDev\LarapexCharts\LarapexChart::cdn()); ?>"></script>
    <?php echo $trendChart->script(); ?>

    <?php echo $cancelChart->script(); ?>


    
    <script>
        (function () {
            var options = {
                chart: {
                    id: '<?php echo $monthlyChart->id(); ?>',
                    type: '<?php echo $monthlyChart->type(); ?>',
                    height: <?php echo $monthlyChart->height(); ?>,
                    width: '<?php echo $monthlyChart->width(); ?>',
                    toolbar: <?php echo $monthlyChart->toolbar(); ?>,
                    zoom: <?php echo $monthlyChart->zoom(); ?>,
                    fontFamily: '<?php echo $monthlyChart->fontFamily(); ?>',
                    foreColor: '<?php echo $monthlyChart->foreColor(); ?>',
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        distributed: true
                    }
                },
                colors: <?php echo $monthlyChart->colors(); ?>,
                series: <?php echo $monthlyChart->dataset(); ?>,
                dataLabels: <?php echo $monthlyChart->dataLabels(); ?>,
                title: {
                    text: "<?php echo $monthlyChart->title(); ?>"
                },
                xaxis: <?php echo $monthlyChart->xAxis(); ?>,
                grid: <?php echo $monthlyChart->grid(); ?>,
                legend: {
                    show: false
                }
            };
            new ApexCharts(document.querySelector("#<?php echo $monthlyChart->id(); ?>"), options).render();
        })();
    </script>

    <?php echo $peakChart->script(); ?>

    <?php $__currentLoopData = $courtCharts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $cc['chart']->script(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo $occChart->script(); ?>


    
    <?php $__currentLoopData = [$memberChart, $visitChart]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statChart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script>
            (function () {
                var options = {
                    chart: {
                        id: '<?php echo $statChart->id(); ?>',
                        type: '<?php echo $statChart->type(); ?>',
                        height: <?php echo $statChart->height(); ?>,
                        width: '<?php echo $statChart->width(); ?>',
                        toolbar: <?php echo $statChart->toolbar(); ?>,
                        zoom: <?php echo $statChart->zoom(); ?>,
                        fontFamily: '<?php echo $statChart->fontFamily(); ?>',
                        foreColor: '<?php echo $statChart->foreColor(); ?>',
                    },
                    plotOptions: {
                        bar: {
                            horizontal: false,
                            distributed: true,
                            borderRadius: 6,
                            columnWidth: '45%'
                        }
                    },
                    colors: <?php echo $statChart->colors(); ?>,
                    series: <?php echo $statChart->dataset(); ?>,
                    dataLabels: <?php echo $statChart->dataLabels(); ?>,
                    xaxis: <?php echo $statChart->xAxis(); ?>,
                    grid: <?php echo $statChart->grid(); ?>,
                    legend: { show: false }
                };
                new ApexCharts(document.querySelector("#<?php echo $statChart->id(); ?>"), options).render();
            })();
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\GitHub\rentbas\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>