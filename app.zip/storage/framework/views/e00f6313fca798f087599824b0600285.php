<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'dirty' => false,
    'savedLabel' => 'บันทึกแล้ว',
    'dirtyLabel' => 'ยังไม่บันทึก',
    'savedClass' => 'border-green-200 bg-green-50 text-green-700',
    'dirtyClass' => 'border-yellow-200 bg-yellow-50 text-yellow-700',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'dirty' => false,
    'savedLabel' => 'บันทึกแล้ว',
    'dirtyLabel' => 'ยังไม่บันทึก',
    'savedClass' => 'border-green-200 bg-green-50 text-green-700',
    'dirtyClass' => 'border-yellow-200 bg-yellow-50 text-yellow-700',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<span <?php echo e($attributes->merge([
    'class' => 'js-save-status inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold ' . ($dirty ? $dirtyClass : $savedClass),
    'data-saved-label' => $savedLabel,
    'data-dirty-label' => $dirtyLabel,
    'data-saved-class' => $savedClass,
    'data-dirty-class' => $dirtyClass,
])); ?>>
    <?php echo e($dirty ? $dirtyLabel : $savedLabel); ?>

</span>
<?php /**PATH C:\Users\User\Documents\GitHub\rentbas\resources\views/components/save-status.blade.php ENDPATH**/ ?>