<?php $__env->startSection('title', 'ข้อมูลผู้ใช้: ' . $user->name); ?>

<?php
    function getStatusDetails($status) {
        return match($status) {
            'pending'   => ['bg-yellow-100 text-yellow-700', 'bg-yellow-500', 'รออนุมัติ'],
            'approved'  => ['bg-green-100 text-green-700', 'bg-green-500', 'อนุมัติ'],
            'rejected'  => ['bg-red-100 text-red-700', 'bg-red-500', 'ปฏิเสธ'],
            'cancelled' => ['bg-gray-100 text-gray-600', 'bg-gray-400', 'ยกเลิก'],
            'expired'   => ['bg-gray-100 text-gray-600', 'bg-gray-500', 'เลยกำหนด'],
            default     => ['bg-gray-100 text-gray-700', 'bg-gray-400', $status],
        };
    }
?>

<?php $__env->startSection('content'); ?>
<div class="bg-slate-50 text-gray-900 min-h-screen py-8">
    <div class="container mx-auto px-6 max-w-5xl">

        
        <a href="<?php echo e(route('admin.users.index')); ?>"
           class="inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-orange-500 mb-6 transition font-medium group">
            <svg class="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            กลับไปหน้าจัดการผู้ใช้งาน
        </a>

        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6 border-t-4 border-t-orange-500">
            <div class="flex flex-col sm:flex-row sm:items-center gap-4">
                
                <div class="w-14 h-14 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                    <span class="text-orange-600 text-xl font-bold"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
                </div>
                <div class="flex-1">
                    <h1 class="text-xl font-semibold text-gray-800"><?php echo e($user->name); ?></h1>
                    <div class="flex flex-wrap gap-x-4 gap-y-1 mt-1 text-sm text-gray-500">
                        <span class="flex items-center gap-1">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            <?php echo e($user->email); ?>

                        </span>
                        <span class="flex items-center gap-1">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                            </svg>
                            สมัครเมื่อ <?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d/m/Y')); ?>

                        </span>
                        <?php if($user->is_verified): ?>
                            <span class="inline-flex items-center gap-1 text-green-600">
                                <span class="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                ยืนยัน OTP แล้ว
                            </span>
                        <?php else: ?>
                            <span class="inline-flex items-center gap-1 text-red-500">
                                <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                                ยังไม่ยืนยัน OTP
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="flex gap-2 shrink-0">
                    <a href="<?php echo e(route('admin.credits.show', $user)); ?>" class="flex items-center gap-1.5 bg-emerald-50 text-emerald-600 border border-emerald-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-emerald-100 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5">
                            <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
                        </svg>
                        จัดการเครดิต (<?php echo e(number_format($user->credit_balance / 100, 0)); ?> บาท)
                    </a>
                    <button id="tab-current" class="flex items-center gap-1.5 bg-blue-50 text-blue-600 border border-blue-200 px-4 py-2 rounded-lg text-sm font-medium transition cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5">
                            <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
                        </svg>
                        ปัจจุบัน (<?php echo e($currentBookings->count()); ?>)
                    </button>
                    <button id="tab-past" class="flex items-center gap-1.5 bg-gray-100 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition cursor-pointer">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5">
                            <path d="M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z"/>
                        </svg>
                        ประวัติ (<?php echo e($pastBookings->count()); ?>)
                    </button>
                </div>
            </div>
        </div>

        
        <section id="current-bookings" class="mb-6 scroll-mt-24 transition-opacity duration-300">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-green-500"></span>
                    <h2 class="font-medium text-gray-700 text-sm">คำขอจองปัจจุบัน</h2>
                    <span class="ml-auto text-xs bg-green-50 text-green-600 border border-green-200 px-2.5 py-0.5 rounded-full font-medium">
                        <?php echo e($currentBookings->count()); ?> รายการ
                    </span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-slate-50 text-gray-400 text-xs uppercase tracking-wide border-b border-gray-200">
                            <tr>
                                <th class="px-6 py-3 font-medium">วันที่</th>
                                <th class="px-6 py-3 font-medium">เวลา</th>
                                <th class="px-6 py-3 font-medium">สนาม</th>
                                <th class="px-6 py-3 font-medium">สถานะ</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if($currentBookings->isEmpty()): ?>
                                <tr>
                                    <td colspan="4" class="px-6 py-12 text-center text-gray-400 text-sm">ไม่พบข้อมูลคำขอจองปัจจุบัน</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $currentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $bookingEndTime = \Carbon\Carbon::parse($b->booking_date)->setTimeFromTimeString($b->end_time);
                                        $currentStatus = ($b->status === 'pending' && $bookingEndTime->isPast()) ? 'expired' : $b->status;
                                        [$badgeClass, $dotClass, $statusLabel] = getStatusDetails($currentStatus);
                                    ?>
                                    <tr class="hover:bg-slate-50 transition">
                                        <td class="px-6 py-4 text-gray-600"><?php echo e(\Carbon\Carbon::parse($b->booking_date)->format('d/m/Y')); ?></td>
                                        <td class="px-6 py-4 text-gray-800"><?php echo e(substr($b->start_time, 0, 5)); ?> - <?php echo e(substr($b->end_time, 0, 5)); ?></td>
                                        <td class="px-6 py-4 text-gray-500"><?php echo e($b->court->name); ?></td>
                                        <td class="px-6 py-4">
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($badgeClass); ?>">
                                                <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotClass); ?>"></span>
                                                <?php echo e($statusLabel); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        
        <section id="past-bookings" class="scroll-mt-24 hidden transition-opacity duration-300">
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-gray-400"></span>
                    <h2 class="font-medium text-gray-700 text-sm">ประวัติการปฏิเสธ / ยกเลิก / ที่ผ่านมา</h2>
                    <span class="ml-auto text-xs bg-gray-50 text-gray-600 border border-gray-200 px-2.5 py-0.5 rounded-full font-medium">
                        <?php echo e($pastBookings->count()); ?> รายการ
                    </span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left">
                        <thead class="bg-slate-50 text-gray-400 text-xs uppercase tracking-wide border-b border-gray-200">
                            <tr>
                                <th class="px-6 py-3 font-medium">วันที่</th>
                                <th class="px-6 py-3 font-medium">เวลา</th>
                                <th class="px-6 py-3 font-medium">สนาม</th>
                                <th class="px-6 py-3 font-medium">สถานะ</th>
                                <th class="px-6 py-3 font-medium">เหตุผล</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if($pastBookings->isEmpty()): ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-12 text-center text-gray-400 text-sm">ไม่พบข้อมูลประวัติการจอง</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $pastBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $bookingEndTime = \Carbon\Carbon::parse($b->booking_date)->setTimeFromTimeString($b->end_time);
                                        $currentStatus = ($b->status === 'pending' && $bookingEndTime->isPast()) ? 'expired' : $b->status;
                                        [$badgeClass, $dotClass, $statusLabel] = getStatusDetails($currentStatus);
                                    ?>
                                    <tr class="hover:bg-slate-50 transition">
                                        <td class="px-6 py-4 text-gray-600"><?php echo e(\Carbon\Carbon::parse($b->booking_date)->format('d/m/Y')); ?></td>
                                        <td class="px-6 py-4 text-gray-800"><?php echo e(substr($b->start_time, 0, 5)); ?> - <?php echo e(substr($b->end_time, 0, 5)); ?></td>
                                        <td class="px-6 py-4 text-gray-500"><?php echo e($b->court->name); ?></td>
                                        <td class="px-6 py-4">
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium <?php echo e($badgeClass); ?>">
                                                <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotClass); ?>"></span>
                                                <?php echo e($statusLabel); ?>

                                            </span>
                                        </td>
                                        <td class="px-6 py-4 text-gray-500 text-xs"><?php echo e($b->reject_reason ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const tabCurrent = document.getElementById('tab-current');
    const tabPast = document.getElementById('tab-past');
    const secCurrent = document.getElementById('current-bookings');
    const secPast = document.getElementById('past-bookings');

    tabCurrent.addEventListener('click', function() {
        secCurrent.classList.remove('hidden');
        secPast.classList.add('hidden');

        tabCurrent.className = "flex items-center gap-1.5 bg-blue-50 text-blue-600 border border-blue-200 px-4 py-2 rounded-lg text-sm font-medium transition cursor-pointer";
        tabPast.className = "flex items-center gap-1.5 bg-gray-100 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition cursor-pointer";
    });

    tabPast.addEventListener('click', function() {
        secCurrent.classList.add('hidden');
        secPast.classList.remove('hidden');

        tabPast.className = "flex items-center gap-1.5 bg-blue-50 text-blue-600 border border-blue-200 px-4 py-2 rounded-lg text-sm font-medium transition cursor-pointer";
        tabCurrent.className = "flex items-center gap-1.5 bg-gray-100 text-gray-700 border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition cursor-pointer";
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\User\Documents\GitHub\rentbas\resources\views/admin/users/show.blade.php ENDPATH**/ ?>